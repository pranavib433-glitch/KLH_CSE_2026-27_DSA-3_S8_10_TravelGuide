import java.util.Arrays;
import java.util.Comparator;

final class StringAlgorithms {

        /** Levenshtein distance (dynamic programming). */
        static int editDistance(String a, String b) {
            int[][] dp = new int[a.length() + 1][b.length() + 1];
            for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
            for (int j = 0; j <= b.length(); j++) dp[0][j] = j;

            for (int i = 1; i <= a.length(); i++) {
                for (int j = 1; j <= b.length(); j++) {
                    dp[i][j] = a.charAt(i - 1) == b.charAt(j - 1)
                        ? dp[i - 1][j - 1]
                        : 1 + Math.min(dp[i - 1][j - 1],
                                Math.min(dp[i - 1][j], dp[i][j - 1]));
                }
            }
            return dp[a.length()][b.length()];
        }

        /** Knuth-Morris-Pratt: index of first match, or -1. */
        static int kmpSearch(String text, String pattern) {
            if (pattern.isEmpty()) return 0;

            int[] lps = buildLps(pattern);
            int i = 0, j = 0;

            while (i < text.length()) {
                if (text.charAt(i) == pattern.charAt(j)) {
                    i++;
                    j++;
                    if (j == pattern.length()) return i - j;
                } else if (j > 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
            return -1;
        }

        private static int[] buildLps(String pattern) {
            int[] lps = new int[pattern.length()];
            int length = 0;
            int i = 1;

            while (i < pattern.length()) {
                if (pattern.charAt(i) == pattern.charAt(length)) {
                    lps[i++] = ++length;
                } else if (length > 0) {
                    length = lps[length - 1];
                } else {
                    lps[i++] = 0;
                }
            }
            return lps;
        }

        /** Rabin-Karp rolling hash: index of first match, or -1. */
        static int rabinKarpSearch(String text, String pattern) {
            if (pattern.isEmpty()) return 0;
            int m = pattern.length();
            if (m > text.length()) return -1;

            final long mod = 1_000_000_007L;
            final long base = 257;
            long patternHash = 0, windowHash = 0, highestPower = 1;

            for (int i = 0; i < m - 1; i++) highestPower = highestPower * base % mod;

            for (int i = 0; i < m; i++) {
                patternHash = (patternHash * base + pattern.charAt(i)) % mod;
                windowHash = (windowHash * base + text.charAt(i)) % mod;
            }

            for (int i = 0; i <= text.length() - m; i++) {
                if (patternHash == windowHash && text.regionMatches(i, pattern, 0, m))
                    return i;

                if (i < text.length() - m) {
                    windowHash = (windowHash - text.charAt(i) * highestPower % mod + mod) % mod;
                    windowHash = (windowHash * base + text.charAt(i + m)) % mod;
                }
            }
            return -1;
        }

        /** Longest common substring using a suffix array and LCP array. */
        static String longestCommonSubstring(String a, String b) {
            String combined = a + "{" + b; // '{' sorts after lowercase letters
            int separator = a.length();

            int[] sa = buildSuffixArray(combined);
            int[] lcp = buildLcpArray(combined, sa);

            int bestLength = 0, bestPosition = -1;

            for (int i = 1; i < sa.length; i++) {
                boolean prevInA = sa[i - 1] < separator;
                boolean currInA = sa[i] < separator;

                if (prevInA != currInA && lcp[i] > bestLength) {
                    bestLength = lcp[i];
                    bestPosition = Math.min(sa[i - 1], sa[i]);
                }
            }
            return bestLength == 0 ? "" : combined.substring(bestPosition, bestPosition + bestLength);
        }

        // Simple suffix sorting; fine for short descriptions.
        private static int[] buildSuffixArray(String text) {
            Integer[] suffixes = new Integer[text.length()];
            for (int i = 0; i < suffixes.length; i++) suffixes[i] = i;

            Arrays.sort(suffixes, Comparator.comparing(text::substring));

            int[] sa = new int[suffixes.length];
            for (int i = 0; i < sa.length; i++) sa[i] = suffixes[i];
            return sa;
        }

        // Kasai's algorithm.
        private static int[] buildLcpArray(String text, int[] sa) {
            int n = text.length();
            int[] rank = new int[n];
            int[] lcp = new int[n];
            for (int i = 0; i < n; i++) rank[sa[i]] = i;

            int common = 0;
            for (int i = 0; i < n; i++) {
                if (rank[i] == 0) {
                    common = 0;
                    continue;
                }
                int j = sa[rank[i] - 1];
                while (i + common < n && j + common < n
                        && text.charAt(i + common) == text.charAt(j + common)) {
                    common++;
                }
                lcp[rank[i]] = common;
                if (common > 0) common--;
            }
            return lcp;
        }
    }
