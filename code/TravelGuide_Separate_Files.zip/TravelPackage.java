enum TravelPackage {
        BUDGET("Budget Package", 2, 4999),
        STANDARD("Standard Package", 4, 8999),
        PREMIUM("Premium Package", 6, 14999);

        final String label;
        final int days;
        final double pricePerPerson;

        TravelPackage(String label, int days, double pricePerPerson) {
            this.label = label;
            this.days = days;
            this.pricePerPerson = pricePerPerson;
        }

        int nights() {
            return days - 1;
        }
    }
