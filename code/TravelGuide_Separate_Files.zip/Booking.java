final class Booking {
        final String traveler;
        final Destination destination;
        final String date;
        final TravelPackage pack;
        final int travelers;

        Booking(String traveler, Destination destination, String date,
                TravelPackage pack, int travelers) {
            this.traveler = traveler;
            this.destination = destination;
            this.date = date;
            this.pack = pack;
            this.travelers = travelers;
        }

        double total() {
            return pack.pricePerPerson * travelers;
        }

        @Override
        public String toString() {
            return String.format("%s | %s | %s | %s | Travelers: %d | Total: Rs. %.2f",
                    traveler, destination.name, date, pack.label, travelers, total());
        }
    }
