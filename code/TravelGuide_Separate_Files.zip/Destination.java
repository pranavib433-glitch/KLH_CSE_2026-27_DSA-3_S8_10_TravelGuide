import java.util.Arrays;
import java.util.List;

final class Destination {
        final int id;
        final String name;
        final String speciality;
        final List<String> places;
        final String bestMonths;
        final String weather;
        final String precaution;
        final String thingsToCarry;
        final String transport;
        boolean favorite;

        Destination(int id, String name, String speciality, String places,
                    String bestMonths, String weather, String precaution,
                    String thingsToCarry, String transport) {
            this.id = id;
            this.name = name;
            this.speciality = speciality;
            this.places = Arrays.asList(places.split(",\\s*"));
            this.bestMonths = bestMonths;
            this.weather = weather;
            this.precaution = precaution;
            this.thingsToCarry = thingsToCarry;
            this.transport = transport;
        }

        /** Text used by the word-search feature. */
        String searchableText() {
            return (name + " " + speciality + " " + String.join(", ", places)).toLowerCase();
        }
    }
