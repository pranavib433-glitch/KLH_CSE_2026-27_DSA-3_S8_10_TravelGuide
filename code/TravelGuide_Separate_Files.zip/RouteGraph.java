import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

final class RouteGraph {
        static final int INF = 1_000_000_000;
        private final int[][] weight;

        RouteGraph(int n) {
            weight = new int[n][n];
            for (int[] row : weight) Arrays.fill(row, INF);
            for (int i = 0; i < n; i++) weight[i][i] = 0;
        }

        void addRoute(int a, int b, int km) {
            weight[a][b] = km;
            weight[b][a] = km;
        }

        /** Dijkstra: returns {distance[], parent[]}. */
        int[][] dijkstra(int start) {
            int n = weight.length;
            int[] dist = new int[n];
            int[] parent = new int[n];
            Arrays.fill(dist, INF);
            Arrays.fill(parent, -1);
            dist[start] = 0;

            PriorityQueue<int[]> queue = new PriorityQueue<>(Comparator.comparingInt(x -> x[1]));
            queue.add(new int[]{start, 0});

            while (!queue.isEmpty()) {
                int[] top = queue.poll();
                int node = top[0];
                if (top[1] > dist[node]) continue; // stale entry

                for (int next = 0; next < n; next++) {
                    if (weight[node][next] >= INF) continue;
                    int candidate = dist[node] + weight[node][next];
                    if (candidate < dist[next]) {
                        dist[next] = candidate;
                        parent[next] = node;
                        queue.add(new int[]{next, candidate});
                    }
                }
            }
            return new int[][]{dist, parent};
        }

        /** Floyd-Warshall all-pairs shortest paths. */
        int[][] allPairs() {
            int n = weight.length;
            int[][] dist = new int[n][];
            for (int i = 0; i < n; i++) dist[i] = weight[i].clone();

            for (int k = 0; k < n; k++)
                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n; j++)
                        if (dist[i][k] < INF && dist[k][j] < INF
                                && dist[i][k] + dist[k][j] < dist[i][j])
                            dist[i][j] = dist[i][k] + dist[k][j];
            return dist;
        }
    }
