import java.util.Scanner;

final class Input {
        private static final Scanner SC = new Scanner(System.in);

        static String text(String prompt) {
            while (true) {
                System.out.print(prompt);
                String value = SC.nextLine().trim();
                if (!value.isEmpty()) return value;
                System.out.println("This field cannot be empty.");
            }
        }

        static int integer(String prompt) {
            while (true) {
                System.out.print(prompt);
                try {
                    return Integer.parseInt(SC.nextLine().trim());
                } catch (NumberFormatException e) {
                    System.out.println("Enter a valid whole number.");
                }
            }
        }

        static int integer(String prompt, int min, int max) {
            while (true) {
                int value = integer(prompt);
                if (value >= min && value <= max) return value;
                System.out.printf("Enter a number from %d to %d.%n", min, max);
            }
        }

        static double amount(String prompt) {
            while (true) {
                System.out.print(prompt);
                try {
                    double value = Double.parseDouble(SC.nextLine().trim());
                    if (Double.isFinite(value) && value >= 0) return value;
                    System.out.println("Enter a non-negative amount.");
                } catch (NumberFormatException e) {
                    System.out.println("Enter a valid amount.");
                }
            }
        }

        static boolean confirm(String prompt) {
            return text(prompt + " (Y/N): ").equalsIgnoreCase("Y");
        }

        static void close() {
            SC.close();
        }
    }
